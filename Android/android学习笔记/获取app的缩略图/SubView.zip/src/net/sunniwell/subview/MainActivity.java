package net.sunniwell.subview;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import net.sunniwell.jar.log.SWLogger;
import android.R.integer;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private SWLogger log = SWLogger.getLogger(MainActivity.class);
	private ActivityManager mManager;
	private static String TAG = "main";
	private Bitmap bitmap = null;
	private ImageView mImageView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		initView();
		 
	}

	private void initView() {
		mImageView = (ImageView) findViewById(R.id.main_bitmap);
	}

	private Bitmap initData(ActivityManager manager,int id) {
		log.d("init data");
		mManager = (ActivityManager) MainActivity.this
				.getSystemService(ACTIVITY_SERVICE);
		 
		Field taskThumbnailsBitmap = null;
		try {
			Method getTaskTopThumbnail = mManager.getClass()
					.getDeclaredMethod("getTaskTopThumbnail", int.class);
			log.d("getTaskThumbnails ==null ?" + (getTaskTopThumbnail == null));
			if (getTaskTopThumbnail != null) {
				getTaskTopThumbnail.setAccessible(true); 
				Object thumbnails = getTaskTopThumbnail.invoke(mManager, Integer
						.valueOf(id));
				if (thumbnails != null) {
					log.d("thumbnaisl is not null");
					return  (Bitmap) thumbnails;
//					if (taskThumbnailsBitmap == null) {
//						log.d("taskThumbnailBitmap is null");
//						try {
//							taskThumbnailsBitmap = thumbnails.getClass()
//									.getField("mainThumbnail");
//						} catch (NoSuchFieldException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//					}
					// if (taskThumbnailsBitmap != null) {
					// log.d("taskThumbnailBitmap is not null");
					// return (Bitmap) taskThumbnailsBitmap.get(thumbnails);
					// }
				}
			}

		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		log.d(" get bitmap is null");
		return null;
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		bitmap =loadThumbnail(0);
		if (bitmap != null) {
			log.d("main, bitmap is not null ");
			mImageView.setImageBitmap(bitmap);
		} else {
			log.d("mian: bitmap is null");
		}
	}

	 Bitmap loadThumbnail(int index) {  
	        ActivityManager am = (ActivityManager) this  
	                .getSystemService(Context.ACTIVITY_SERVICE);  
	        List<ActivityManager.RecentTaskInfo> recentTasks = am.getRecentTasks(  
	                5, ActivityManager.RECENT_IGNORE_UNAVAILABLE);  
	        int numTasks = recentTasks.size();  
	  
	        if (index < numTasks) {  
	            final ActivityManager.RecentTaskInfo info = recentTasks.get(index);  
	            if (info != null) {  
	                Bitmap b =  initData(am,  
	                        info.persistentId);  
	                return b;  
	            }  
	        }  
	        return null;  
	    }
	
	public static void listAllObject(String classFullName) {
		try {
			Log.i(TAG, "listAllObject classFullName: " + classFullName);
			Class<?> clazz = Class.forName(classFullName);

			// 反射属性字段
			Field[] fields = clazz.getDeclaredFields();

			// 反射方法字段
			Method[] methods = clazz.getDeclaredMethods();

			// 反射构造器
			Constructor[] constuctors = clazz.getDeclaredConstructors();

			Log.i(TAG, "FIELD========");
			for (Field f : fields) {
				Log.i(TAG, "TYPE: " + f.getType() + " NAME: " + f.getName());
			}

			Log.i(TAG, "METHOD========");
			for (Method m : methods) {
				Log.i(TAG, "METHOD NAME: " + m.getName());
			}

			Log.i(TAG, "CONSTUCTOR========");
			for (Constructor c : constuctors) {
				Log.i(TAG, "NAME:" + c.getName());

				Class[] clss = c.getParameterTypes();
				Object o = null;

				// 产生实例
				try {
					if (clss.length == 0)
						o = c.newInstance();
					else if (clss.length > 0) {
						// TODO
					}
					Log.i(TAG, "object: " + o);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
