package net.sunniwell.subview.view;

import net.sunniwell.jar.log.SWLogger;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

public class MySubView extends View {
	private  SWLogger log =SWLogger.getLogger(MySubView.class);
	public MySubView(Context context) {
		this(context,null);
		 
	}

	public MySubView(Context context, AttributeSet attrs) {
		this(context, attrs,0);
		// TODO Auto-generated constructor stub
	}

	public MySubView(Context context, AttributeSet attrs, int defStyleAttr) {
		super(context, attrs, defStyleAttr);
		initView();
	}

	private void initView(){
		
	}
	
	@Override
	protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
		super.onMeasure(widthMeasureSpec, heightMeasureSpec);
		 setMeasuredDimension(widthMeasureSpec, heightMeasureSpec);
	}
}
